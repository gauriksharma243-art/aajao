# aajao: deploy from your Android phone

aajao needs Node 22.13+ and **no npm packages** (nothing to install). It stores everything in one SQLite database inside `DATA_DIR`.

## 1. Settings (environment variables)

Every capability is switched on **only** by its own settings. Anything you leave out shows as "Not configured" in the app and is never faked.

### Required
| Name | Example | Notes |
|---|---|---|
| `TEXT_PROVIDER` | `anthropic` or `openai` | `openai` also covers OpenAI-compatible services via `TEXT_BASE_URL`. (`AI_PROVIDER` / `AI_API_KEY` / `AI_MODEL` / `AI_BASE_URL` still work as older names.) |
| `TEXT_API_KEY` | `sk-...` | Your key. Stays on the server. |
| `TEXT_MODEL` | the model name from your provider | Use only names your provider really offers. |
| `OWNER_EMAIL` / `OWNER_PASSWORD` | you@example.com / 10+ chars | Your login (the password is used once to create the owner) |
| `NODE_ENV` | `production` | Forces HTTPS, secure cookies |
| `DATA_DIR` | `/data` | Must be on a **persistent disk** |

### Optional capabilities
| Capability | Settings | What it does |
|---|---|---|
| Fast model | `FAST_PROVIDER`, `FAST_API_KEY`, `FAST_MODEL` (+`FAST_BASE_URL`) | Cheaper/quicker replies |
| Reasoning model | `REASONING_*` plus `REASONING_EFFORT` (OpenAI-style) or `REASONING_THINKING_BUDGET` (Anthropic extended thinking) | Harder problems. If it points at the same model as Default with no reasoning setting, the owner panel warns it is **not** actually stronger. Hidden reasoning is never shown. |
| Vision model | `VISION_*` (or `*_SUPPORTS_IMAGES=1` on a chat model) | Understand uploaded images |
| Image generation | `IMAGE_PROVIDER` (`openai` images API, `replicate`, `fal`), `IMAGE_API_KEY`, `IMAGE_MODEL` | "Generate image" |
| Video generation | `VIDEO_PROVIDER` (`replicate`, `fal`), `VIDEO_API_KEY`, `VIDEO_MODEL`, `VIDEO_COST_NOTE`, `VIDEO_SUPPORTS_IMAGE=1` | Asynchronous video, always asks first |
| Web search | `SEARCH_PROVIDER` (`tavily` or `brave`), `SEARCH_API_KEY` | Answers with real source links |
| Voice | not built | Shown as "Not configured" |

### Limits (cost control)
`DAILY_MESSAGE_LIMIT` (default 100), `IMAGE_DAILY_LIMIT` (20), `VIDEO_DAILY_LIMIT` (3 per person per day), `VIDEO_MONTHLY_LIMIT` (30 for the whole app). The owner can change them in the Owner panel. At most 2 generations run at once per person. There is no payment system.

Other: `PUBLIC_URL` (used by Copy Share Link), `OWNER` login is created from the two owner settings.

Supported files: images (PNG/JPEG/GIF/WebP), PDF (needs a model that really reads PDFs, e.g. Anthropic), Word `.docx`, text/CSV/code. Checked by file content, with size limits.

### Honest status of each provider adapter
The adapters follow each provider's documented API, but **NOT VERIFIED against the real services** (no real keys were available when this was built). After you add a key, open Owner panel > AI capabilities: text/fast/reasoning/vision/search have a **Test** button (one tiny real request). Image and video cannot be tested for free, so they become "Verified" only after one real generation succeeds. Until then they show "Not verified". If a provider changes its API, the failure appears there as "Failed" with the reason.

## 2. Costs (explained before you spend anything)

- **Hosting:** needs a web server that keeps a disk. Free web tiers usually have **no persistent disk**, which would delete accounts and chats on every restart. A small paid instance plus a disk is the realistic minimum on Render. **NOT VERIFIED:** I could not open current pricing from my environment. Check the host's pricing page before you click create.
- **AI usage:** you pay your AI provider per message. `DAILY_MESSAGE_LIMIT` caps each invited user.
- **Images and videos cost real money at your generation provider** (video especially). Each video asks for confirmation and shows your `VIDEO_COST_NOTE` and how many are left. Prices are set by the provider: I did not verify any. Check them before you set the limits (for roughly 20 to 30 videos, set `VIDEO_MONTHLY_LIMIT=30`).
- **Free alternative to consider:** a free AI tier from some providers (Groq/OpenRouter models) through `AI_PROVIDER=openai` and `AI_BASE_URL`. Quality and reliability vary.
- Nothing is created for you. You press every button.

## 3. Deploy on Render (from a phone browser)

1. Put the project in a **private** GitHub repository (upload the zip's contents; `.gitignore` already excludes `data/`).
2. Render dashboard > New > Web Service > choose the repo. Runtime Node. Build command: leave empty. Start command: `node server.js`.
3. Choose an instance type that supports a Disk. Add a Disk with mount path `/data`.
4. Add the environment variables above. `render.yaml` in this folder lists them; secrets are entered by you.
5. Deploy. Render shows an `https://....onrender.com` address. That is your one share link.

## 4. How people log in

- **You (owner):** open the link, sign in with `OWNER_EMAIL` and `OWNER_PASSWORD`. Account menu > Owner panel.
- **Invite someone:** Owner panel > email > Create invitation. Press **Copy invite message** and send it on WhatsApp (it contains the link, their email and a one-time code, valid 7 days).
- **They:** open the link, tap **I have an invite code**, enter email + code, choose a password. Next time they just sign in.
- **Forgot password:** Owner panel > Reset code next to their name, send the code; they use "I have an invite code" again.
- **Revoke:** Disable (instant sign-out, reversible) or Remove (deletes their chats).

## 5. Test before telling anyone it works (these are YOURS to confirm)

On a different phone or browser, on mobile data:
1. Open the link. Only the login page appears.
2. Sign in as an invited test user and send a message. You must receive a **real** AI reply (this is the only proof the AI key works).
3. Close the browser, reopen the link days later, sign in: the chat is in history.
4. Disable that user in the owner panel: their next action signs them out.
5. Paste the link into WhatsApp and open it from there.

## Not included

- Voice input/output (only prepared as a disabled capability), Android app, payments, "Build your own chatbot".
- Email sending (invites and resets are delivered by you via WhatsApp).
- Database backups: copy `DATA_DIR/aajao.db` and `DATA_DIR/files` if you want a backup.

## Tests included (all provider calls in them are MOCKS)
`npm test` (21 core tests with both text providers + 23 multimodal tests) and `npm run test:ui` (29 + 47 phone-size 360x740 browser checks; needs Playwright). They prove aajao's own logic. They do **not** prove your real keys or provider work.
