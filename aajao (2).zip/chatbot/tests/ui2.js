"use strict";
// Phone-size (360x740) browser checks for the multimodal UI. EVERY upstream provider here is a MOCK server.
// This proves aajao's own UI/flows. It does not prove any real provider works.
const http = require("node:http");
const path = require("node:path");
const fs = require("node:fs");
const os = require("node:os");
const { spawn } = require("node:child_process");
const { chromium } = require(process.env.PLAYWRIGHT_PATH || "/opt/npm-tools/node_modules/playwright");

const SHOTS = process.env.SHOTS_DIR || fs.mkdtempSync(path.join(os.tmpdir(), "aajao-shots2-"));
fs.mkdirSync(SHOTS, { recursive: true });
const PNG = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg==", "base64");
const MP4 = (() => { const b = Buffer.alloc(5000, 7); b.writeUInt32BE(24, 0); b.write("ftypisom", 4, "latin1"); return b; })();
const results = [];
const check = (name, ok, extra = "") => { results.push({ name, ok }); console.log((ok ? "PASS " : "FAIL ") + "[MOCK] " + name + (extra ? "  " + extra : "")); };
const readJson = (req) => new Promise((r) => { let b = ""; req.on("data", (c) => (b += c)); req.on("end", () => { try { r(JSON.parse(b || "{}")); } catch { r({}); } }); });
const send = (res, code, obj) => { res.writeHead(code, { "content-type": "application/json" }); res.end(JSON.stringify(obj)); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let released = false, videoCalls = 0, mockPort = 0;

function startMock() {
  const srv = http.createServer(async (req, res) => {
    const url = new URL(req.url, "http://x"); const p = url.pathname;
    const body = req.method === "POST" ? await readJson(req) : {};
    if (p === "/release") { released = true; return send(res, 200, {}); }
    if (p === "/files/video.mp4") { res.writeHead(200, { "content-type": "video/mp4" }); return res.end(MP4); }
    if (p === "/v1/messages" || p === "/v1/chat/completions") {
      const isA = p === "/v1/messages";
      const sys = isA ? String(body.system || "") : String((body.messages[0] || {}).content || "");
      res.writeHead(200, { "content-type": "text/event-stream" });
      const title = /short title/i.test(sys);
      const reply = title ? "Mock Title" : `MOCK[${body.model}] hello from the mock model`;
      if (isA) {
        if (body.thinking) res.write(`event: content_block_delta\ndata: ${JSON.stringify({ type: "content_block_delta", delta: { type: "thinking_delta", thinking: "HIDDEN-THOUGHT-XYZ" } })}\n\n`);
        for (const w of reply.split(/(?<= )/)) res.write(`event: content_block_delta\ndata: ${JSON.stringify({ type: "content_block_delta", delta: { type: "text_delta", text: w } })}\n\n`);
      } else {
        for (const w of reply.split(/(?<= )/)) res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: w } }] })}\n\n`);
        res.write("data: [DONE]\n\n");
      }
      return res.end();
    }
    if (p === "/v1/images/generations") {
      if (String(body.prompt).includes("FAILIMG")) return send(res, 500, { error: "boom" });
      return send(res, 200, { data: [{ b64_json: PNG.toString("base64") }] });
    }
    if (req.method === "POST" && p === "/v1/models/mock/video/predictions") {
      videoCalls++;
      return send(res, 201, { id: "pred1", status: "starting", urls: { get: `http://127.0.0.1:${mockPort}/v1/predictions/pred1` } });
    }
    if (req.method === "GET" && p === "/v1/predictions/pred1") {
      if (!released) return send(res, 200, { status: "processing" });
      return send(res, 200, { status: "succeeded", output: [`http://127.0.0.1:${mockPort}/files/video.mp4`] });
    }
    if (p === "/search") return send(res, 200, { results: [
      { title: "Source One", url: "https://example.org/one", content: "First." },
      { title: "Evil", url: "javascript:alert(1)", content: "bad" },
      { title: "Source Two", url: "https://example.net/two", content: "Second." } ] });
    send(res, 404, {});
  });
  return new Promise((r) => srv.listen(0, "127.0.0.1", () => { mockPort = srv.address().port; r(srv); }));
}
function launch(env) {
  const port = 5900 + Math.floor(Math.random() * 90);
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), "aajao-ui2-"));
  const proc = spawn(process.execPath, ["--no-warnings", path.join(__dirname, "..", "server.js")], {
    env: { PATH: process.env.PATH, PORT: String(port), DATA_DIR: dataDir, NODE_ENV: "test", OWNER_EMAIL: "owner@example.com", OWNER_PASSWORD: "owner-password-123", ...env }, stdio: "ignore" });
  return new Promise((r) => setTimeout(() => r({ proc, base: `http://127.0.0.1:${port}` }), 1300));
}

(async () => {
  const mock = await startMock();
  const b = `http://127.0.0.1:${mockPort}/v1`;
  const full = await launch({
    TEXT_PROVIDER: "anthropic", TEXT_API_KEY: "k1", TEXT_MODEL: "mock-text", TEXT_BASE_URL: b,
    FAST_PROVIDER: "openai", FAST_API_KEY: "k2", FAST_MODEL: "mock-fast", FAST_BASE_URL: b,
    REASONING_PROVIDER: "anthropic", REASONING_API_KEY: "k3", REASONING_MODEL: "mock-reasoner", REASONING_BASE_URL: b, REASONING_THINKING_BUDGET: "2000",
    AI_SUPPORTS_IMAGES: "1", TEXT_SUPPORTS_IMAGES: "1",
    IMAGE_PROVIDER: "openai", IMAGE_API_KEY: "k4", IMAGE_MODEL: "mock-image", IMAGE_BASE_URL: b,
    VIDEO_PROVIDER: "replicate", VIDEO_API_KEY: "k5", VIDEO_MODEL: "mock/video", VIDEO_BASE_URL: b, VIDEO_COST_NOTE: "MOCK cost note: about 0.40 per video",
    SEARCH_PROVIDER: "tavily", SEARCH_API_KEY: "k6", SEARCH_BASE_URL: `http://127.0.0.1:${mockPort}`,
    ALLOW_INSECURE_LOCAL_MEDIA: "1", GEN_POLL_MS: "50", IMAGE_DAILY_LIMIT: "50", VIDEO_DAILY_LIMIT: "50", VIDEO_MONTHLY_LIMIT: "50" });
  const minimal = await launch({ TEXT_PROVIDER: "anthropic", TEXT_API_KEY: "k1", TEXT_MODEL: "mock-text", TEXT_BASE_URL: b });

  const browser = await chromium.launch({ args: ["--no-sandbox"] });
  const mk = async () => browser.newContext({ viewport: { width: 360, height: 740 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true,
    userAgent: "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36", permissions: ["clipboard-read", "clipboard-write"] });
  const errors = [];
  const watch = (page) => { page.on("pageerror", (e) => errors.push(e.message)); page.on("console", (m) => { if (m.type() === "error" && !/status of 401/.test(m.text())) errors.push(m.text()); }); };
  const noH = (page) => page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1 && document.body.scrollWidth <= innerWidth + 1);
  const login = async (page, base) => {
    await page.goto(base); await page.waitForSelector("#auth-view:not(.hidden)");
    await page.fill("#a-email", "owner@example.com"); await page.fill("#a-pw", "owner-password-123"); await page.tap("#a-submit");
    await page.waitForSelector("#app:not(.hidden)");
  };
  const menuItems = (page) => page.$$eval("#menu button", (bs) => bs.map((x) => ({ text: x.textContent, disabled: x.classList.contains("disabled"), h: x.getBoundingClientRect().height })));
  const inView = (page, sel) => page.evaluate((s) => { const r = document.querySelector(s).getBoundingClientRect(); return r.left >= 0 && r.right <= innerWidth && r.top >= 0 && r.bottom <= innerHeight; }, sel);

  try {
    const ctx = await mk(); const page = await ctx.newPage(); watch(page);
    await login(page, full.base);

    // ---- + action menu
    await page.tap("#attach-btn");
    let items = await menuItems(page);
    check("+ menu lists the 6 actions", ["Upload image", "Upload file", "Generate image", "Generate video", "Web search", "Reasoning mode"].every((l) => items.some((i) => i.text.includes(l))) && items.length === 6, JSON.stringify(items.map((i) => i.text)));
    check("+ menu rows are touch-sized and menu fits the screen", items.every((i) => i.h >= 44) && await inView(page, "#menu"));
    check("all configured actions are enabled", items.every((i) => !i.disabled));
    await page.screenshot({ path: path.join(SHOTS, "m1-plus-menu.png") });
    await page.keyboard.press("Escape"); await page.tap("#messages");

    // ---- model selector
    check("model selector is visible when several models are configured", await page.isVisible("#model-btn"));
    await page.tap("#model-btn");
    items = await menuItems(page);
    check("model menu shows Default/Fast/Reasoning/Smart with configured model names", ["Default", "Fast", "Reasoning", "Smart"].every((l) => items.some((i) => i.text.includes(l))) && items.some((i) => i.text.includes("mock-reasoner")), JSON.stringify(items.map((i) => i.text)));
    await page.screenshot({ path: path.join(SHOTS, "m2-model-menu.png") });
    await page.tap("#menu button:has-text('Reasoning')");
    check("selected mode shows as a chip and on the model button", /Reasoning/.test(await page.textContent("#model-label")) && (await page.textContent("#modes")).includes("Reasoning"));
    await page.fill("#input", "Think hard about this"); await page.tap("#send-btn");
    await page.waitForSelector(".msg.assistant .meta", { timeout: 10000 });
    const metaTxt = await page.textContent(".msg.assistant .meta");
    check("reply shows which model/mode answered", /Reasoning/.test(metaTxt) && /mock-reasoner/.test(metaTxt), metaTxt);
    check("hidden thinking text is never shown", !(await page.content()).includes("HIDDEN-THOUGHT-XYZ"));
    await page.tap("#modes .chip button");
    check("mode chip can be removed", (await page.textContent("#model-label")).trim().startsWith("Default"));

    // ---- web search
    await page.tap("#attach-btn"); await page.tap("#menu button:has-text('Web search')");
    check("Web search shows as a chip", (await page.textContent("#modes")).includes("Web search"));
    await page.fill("#input", "what is new today"); await page.tap("#send-btn");
    await page.waitForFunction(() => document.querySelectorAll(".msg.assistant .sources").length >= 1, null, { timeout: 10000 });
    const links = await page.$$eval(".msg.assistant .sources a", (as) => as.map((a) => a.href));
    check("sources are shown with https links only (javascript: dropped)", links.length === 2 && links.every((l) => l.startsWith("https://")), JSON.stringify(links));
    check("web-assisted reply is tagged", (await page.textContent(".msg.assistant:last-of-type .meta")).includes("Web-assisted"));
    check("no horizontal scroll with sources", await noH(page));
    await page.screenshot({ path: path.join(SHOTS, "m3-sources.png") });
    await page.tap("#modes .chip button");

    // ---- image generation
    await page.tap("#attach-btn"); await page.tap("#menu button:has-text('Generate image')");
    check("Generate image shows as a chip and changes the placeholder", (await page.getAttribute("#input", "placeholder")).includes("image"));
    await page.fill("#input", "a red kite over a beach"); await page.tap("#send-btn");
    await page.waitForSelector(".gen[data-gen=completed] img.gen-img", { timeout: 10000 });
    check("image card shows Completed status and the real image", (await page.textContent(".gen .gen-status")).trim() === "Completed" && await page.$eval(".gen-img", (i) => i.complete && i.naturalWidth > 0));
    check("image card has Download and Generate again", await page.isVisible(".gen a.act:has-text('Download')") && await page.isVisible(".gen button:has-text('Generate again')"));
    check("download link forces download", (await page.getAttribute(".gen a.act", "href")).endsWith("?download=1"));
    await page.screenshot({ path: path.join(SHOTS, "m4-image-card.png") });
    await page.tap(".gen-img");
    check("tapping the image opens the full-screen preview", await page.isVisible("#lightbox") && await inView(page, "#lb-close"));
    await page.screenshot({ path: path.join(SHOTS, "m5-lightbox.png") });
    await page.tap("#lb-close");
    check("preview closes", !(await page.isVisible("#lightbox")));

    // failed image
    await page.fill("#input", "FAILIMG please"); await page.tap("#send-btn");
    await page.waitForSelector(".gen[data-gen=failed]", { timeout: 10000 });
    check("failed generation shows a clear error and Try again", await page.isVisible(".gen[data-gen=failed] .gen-err") && await page.isVisible(".gen[data-gen=failed] button:has-text('Try again')"));
    check("failure message does not leak provider internals", !(await page.textContent(".gen[data-gen=failed] .gen-err")).includes("boom"));
    await page.tap("#modes .chip button");

    // ---- video: confirmation, cost, async status, playback
    await page.tap("#attach-btn"); await page.tap("#menu button:has-text('Generate video')");
    await page.fill("#input", "waves at sunset"); await page.tap("#send-btn");
    await page.waitForSelector("#dialog:not(.hidden)");
    const dlg = await page.textContent("#dialog-msg");
    check("video asks for confirmation and shows cost note and remaining count", /paid credits/.test(dlg) && /MOCK cost note/.test(dlg) && /left today/.test(dlg), dlg);
    await page.screenshot({ path: path.join(SHOTS, "m6-video-confirm.png") });
    await page.tap("#dialog-cancel");
    check("cancelling creates no video and keeps the typed prompt", videoCalls === 0 && (await page.inputValue("#input")) === "waves at sunset");
    await page.tap("#send-btn"); await page.waitForSelector("#dialog:not(.hidden)"); await page.tap("#dialog-ok");
    await page.waitForSelector(".gen[data-gen=queued], .gen[data-gen=processing]", { timeout: 10000 });
    check("video shows a queued/processing status while waiting", /Queued|Processing/.test(await page.textContent(".gen[data-gen=queued] .gen-status, .gen[data-gen=processing] .gen-status")) && videoCalls === 1);
    check("no horizontal scroll while a video is processing", await noH(page));
    await page.screenshot({ path: path.join(SHOTS, "m7-video-processing.png") });
    await page.reload(); await page.waitForSelector("#app:not(.hidden)");
    check("history keeps the generations after reload", await page.$$eval(".gen", (g) => g.length) >= 3);
    await fetch(`http://127.0.0.1:${mockPort}/release`);
    await page.waitForSelector(".gen[data-gen=completed] video.gen-video", { timeout: 15000 });
    check("completed video has controls and plays inline", await page.$eval("video.gen-video", (v) => v.controls && v.playsInline));
    check("video card has Download", await page.isVisible("video.gen-video >> xpath=.. >> a.act:has-text('Download')"));
    await page.screenshot({ path: path.join(SHOTS, "m8-video-done.png") });

    // ---- image upload chip (thumbnail, status, remove)
    await page.tap("#top-new");
    await page.tap("#attach-btn"); const fc = page.waitForEvent("filechooser"); await page.tap("#menu button:has-text('Upload image')");
    await (await fc).setFiles({ name: "photo.png", mimeType: "image/png", buffer: PNG });
    await page.waitForSelector("#chips .chip img");
    check("image attachment chip shows thumbnail, name and ready status", (await page.textContent("#chips")).includes("photo.png") && /ready/.test(await page.textContent("#chips")));
    await page.screenshot({ path: path.join(SHOTS, "m9-upload-chip.png") });
    await page.tap("#chips .chip button");
    check("attachment can be removed before sending", (await page.$$("#chips .chip")).length === 0);
    check("welcome screen offers quick prompts", (await page.$$eval(".suggest button", (b2) => b2.length)) >= 8);
    await page.tap(".suggest button:has-text('Summarize')");
    check("quick prompt fills the composer", /Summarize/.test(await page.inputValue("#input")));

    // ---- owner capabilities
    await page.tap("#menu-btn"); await page.tap("#account-btn"); await page.tap("#menu button:has-text('Owner panel')");
    await page.waitForSelector("#ai-status .cap");
    const caps = await page.$$eval("#ai-status .cap", (rows) => rows.map((r) => ({ id: r.dataset.cap, text: r.textContent })));
    check("owner panel lists all 8 capabilities", caps.length === 8, caps.map((c) => c.id).join(","));
    const st = (id) => (/Not configured/.test(caps.find((c) => c.id === id).text) ? "nc" : /Not verified/.test(caps.find((c) => c.id === id).text) ? "nv" : /Failed/.test(caps.find((c) => c.id === id).text) ? "f" : /Verified/.test(caps.find((c) => c.id === id).text) ? "v" : "?");
    check("capabilities are 'Verified' only if a real (mock) request succeeded earlier in this run; unused ones stay 'Not verified'",
      st("fast") === "nv" && st("vision") === "nc" && st("image") === "f" /* last image attempt was the deliberate failure */ && ["text", "reasoning", "search", "video"].every((id) => st(id) === "v"), caps.map((c) => c.id + ":" + st(c.id)).join(" "));
    check("voice is shown as Not configured", /Not configured/.test(caps.find((c) => c.id === "voice").text));
    check("video cost note visible to owner", /MOCK cost note/.test(caps.find((c) => c.id === "video").text));
    check("generation limits can be edited", await page.isVisible("#set-img-limit") && await page.isVisible("#set-vid-limit") && await page.isVisible("#set-vid-month"));
    check("owner panel has no horizontal scroll", await noH(page));
    await page.screenshot({ path: path.join(SHOTS, "m10-owner-caps.png"), fullPage: false });
    await page.tap("#ai-status .cap[data-cap=text] button");
    await page.waitForFunction(() => /Verified/.test(document.querySelector("#ai-status .cap[data-cap=text] .badge").textContent), null, { timeout: 10000 });
    check("Test button runs a real (mock) request and marks the capability Verified", true);
    check("image/video have no Test button (they cost money)", !(await page.$("#ai-status .cap[data-cap=video] button")) && !(await page.$("#ai-status .cap[data-cap=image] button")));
    await page.tap("#admin-close");

    // ---- sign out
    await page.tap("#menu-btn"); await page.tap("#account-btn"); await page.tap("#menu button:has-text('Sign out')");
    await page.waitForSelector("#auth-view:not(.hidden)", { timeout: 5000 });
    check("Sign out returns to the login page", true);
    await page.goto(full.base + "/");
    await page.waitForSelector("#auth-view:not(.hidden)");
    check("after sign out the app is not reachable without logging in again", !(await page.isVisible("#app")));

    // ---- minimal server: only text configured
    const ctx2 = await mk(); const p2 = await ctx2.newPage(); watch(p2);
    await login(p2, minimal.base);
    check("with only Default configured the model selector is hidden", !(await p2.isVisible("#model-btn")));
    await p2.tap("#attach-btn");
    items = await menuItems(p2);
    const dis = (l) => items.find((i) => i.text.includes(l));
    check("unconfigured actions are shown as 'Not configured' and disabled", ["Generate image", "Generate video", "Web search", "Reasoning mode"].every((l) => dis(l).disabled && /Not configured/.test(dis(l).text)), JSON.stringify(items.map((i) => i.text)));
    await p2.screenshot({ path: path.join(SHOTS, "m11-unconfigured-menu.png") });
    await p2.tap("#menu button:has-text('Generate image')", { force: true }); // aria-disabled: Playwright refuses a normal tap, a real finger can tap it
    await p2.waitForSelector("#toast:not(.hidden)");
    check("tapping an unconfigured action explains it instead of doing anything", /Not configured/.test(await p2.textContent("#toast")) && !(await p2.textContent("#modes")).trim());
    check("no env var names are shown to the user", !/_API_KEY|_PROVIDER|IMAGE_|VIDEO_/.test(await p2.content().then((h) => h.replace(/<script[\s\S]*?<\/script>/g, ""))));

    check("no JavaScript errors in the console", errors.length === 0, errors.join(" | ").slice(0, 300));
  } catch (e) {
    check("test run completed without crashing", false, e.stack.split("\n").slice(0, 3).join(" "));
  }
  await browser.close(); full.proc.kill(); minimal.proc.kill(); mock.close();
  const bad = results.filter((r) => !r.ok);
  console.log(`\n${results.length - bad.length}/${results.length} multimodal UI checks passed (all providers are MOCKS). Screenshots: ${SHOTS}`);
  process.exit(bad.length ? 1 : 0);
})();
